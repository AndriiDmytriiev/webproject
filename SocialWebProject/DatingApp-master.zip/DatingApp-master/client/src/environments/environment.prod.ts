export const environment = {
  production: true,
  apiUrl: 'api/',
  hubUrl: 'hubs/'
};
